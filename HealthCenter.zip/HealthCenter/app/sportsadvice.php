<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class sportsadvice extends Model
{
    //
}
