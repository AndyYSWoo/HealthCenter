<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class healthdevice extends Model
{
    //
}
