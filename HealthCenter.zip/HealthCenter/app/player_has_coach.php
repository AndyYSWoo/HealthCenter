<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class player_has_coach extends Model
{
    //
}
