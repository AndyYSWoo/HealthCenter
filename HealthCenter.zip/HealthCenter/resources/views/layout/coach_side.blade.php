	    <div class="side-nav fixed">
	    <div id="header">
			<img class="circle responsive-img" src="/img/user.jpg" id ="header_img">
			<div>Nina Mcintire</div>
		</div>
  			<ul class="collapsible" data-collapsible="accordion" style="color:black;">
  				<li class="side-title"><a href="/coach">首页</a></li>
				<li class="side-title"><a href="/coach/coach_train">发布训练</a></li>
				<li class="side-title"><a href="#!"class="collapsible-header">学员</a>
					<div class="collapsible-body">
						<ul>
							<li><a href="/coach/trainer" style="margin:0;"> <div  style="height:48px;">
                                    <div style="padding-left:0%;padding-top:6px;">
                                        <div style="width:36px;height:36px;border-radius:50%; overflow:hidden;float:left;">
                                        <img src="/img/user.jpg" class="responsive-img">
                                    </div>
                                    <div style="margin-left:30%;margin-top:-2%;">
                                         Sarah Bullock
                                    </div>
                            		</div>
									</div>
									</a>
                            </li>
							<li> <a href="/coach/trainer" style="margin:0;"><div style="height:48px;">
                                    <div style="padding-left:0%;padding-top:6px;">
                                        <div style="width:36px;height:36px;border-radius:50%; overflow:hidden;float:left;">
                                        <img src="/img/user1.jpg" class="responsive-img">
                                    </div>
                                    <div style="margin-left:30%;margin-top:-2%;">
                                         Alexander Pierc
                                    </div>
									</div>
                            </div></a>
                            </li>
						</ul>
					</div>
				</li>
				<li class="side-title"><a href="/auth/logout">退出</a></li>
  			</ul>
	    </div>