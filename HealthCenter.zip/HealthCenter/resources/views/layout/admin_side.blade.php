	<div class="side-nav fixed">
	    <div id="header">
			<img class="circle responsive-img" src="/img/user.jpg" id ="header_img">
			<div>Nina Mcintire</div>
		</div>
  			<ul class="collapsible" data-collapsible="accordion" style="color:black;">
  				<li class="side-title"><a href="/admin">首页</a></li>
				<li class="side-title"><a href="/admin/create/doctor">添加医生</a></li>
				<li class="side-title"><a href="/admin/create/coach">添加教练</a></li>
				<li class="side-title"><a href="/auth/logout">退出登录</a></li>
  			</ul>
	</div>