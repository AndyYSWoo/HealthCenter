	    <ul id="nav-mobile" class="side-nav fixed" >
            <li class="logo">
                    <img class="circle responsive-img" src="/img/cmp.jpg" id ="header_img">
            </li>
            <hr class="colorgraph">
            <li style="font-size:11px">没有学会游泳, 你就会紧张, 就会不知所措, 就会被水淹没</li>
            <hr class="colorgraph">
            <li><a href="/doctor" class="collapsible-header  waves-effect waves-blue">首页</a></li>
            
            <ul class="collapsible collapsible-accordion">
                <li><a href="#!" class="collapsible-header  waves-effect waves-blue">问诊<span class="badge">2</span></a>
                    <div class="collapsible-body">
                        <ul>
                            <li>问诊信息1</li>
                            <li>问诊信息2</li>
                        </ul>
                    </div>
                </li>
                <li><a href="#!" class="collapsible-header  waves-effect waves-blue">用户</a>
                    <div class="collapsible-body">
                        <ul>
                            <li>陈先生</li>
                            <li>高小姐</li>
                            <li>黄太太</li>
                        </ul>
                    </div>
                </li>
            </ul>
            <!--<li><a href="#!" class="collapsible-header  waves-effect waves-blue">设置</a></li>-->
            <li><a href="/auth/logout" class="collapsible-header  waves-effect waves-blue">退出</a></li>
	    </ul>